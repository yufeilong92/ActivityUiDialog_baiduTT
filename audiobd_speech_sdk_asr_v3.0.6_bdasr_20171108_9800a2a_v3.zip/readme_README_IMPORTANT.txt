本目录下 asr-wakeup-debug.apk 可以直接运行
!!! 点击开始录音按钮前，请先看界面上的说明文字 !!!
!!! 点击开始录音按钮前，请先看界面上的说明文字 !!!

文档：http://speech.baidu.com/docs/asr/166
请测通DEMO后，了解SDK的调用流程后集成。集成文档：http://speech.baidu.com/docs/asr/186

使用Android Studio 最新版本，FILE->OPEN 选本目录 即可打开项目。

问题反馈：
1. QQ群： 在yuyin.baidu.com 底部可以找到QQ群号
2. 论坛:  http://yuyin.baidu.com/bbs/question/stick
3. 商务合作及新功能需求  在yuyin.baidu.com 底部点击“商务合作”



SDK及DEMO BUG反馈格式：
反馈文件下载：http://speech-doc.gz.bcebos.com/android_asr/android%20asr%20%E5%8F%8D%E9%A6%88-%E6%82%A8%E7%9A%84%E8%81%94%E7%B3%BB%E6%96%B9%E5%BC%8F.zip

1. 现象描述
   调用我们的xxx方法之后，报错。
2. 输入参数：
  （DEMO中有反馈参数的日志）
3. 输出结果：
   
4 .用户日志：
  先清空日志，之后调用我们的某个方法结束。请提供给我们之中的完整日志。

5 .手机信息：
   手机型号， android版本号等信息

DEMO 改进建议及文档建议：

1. QQ群： 在yuyin.baidu.com 底部可以找到QQ群号。 在QQ群中@测试。


