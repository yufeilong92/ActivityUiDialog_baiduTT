package com.baidu.android.voicedemo.activity.setting;

import com.baidu.speech.recognizerdemo.R;

/**
 * Created by fujiayi on 2017/6/24.
 */

public class NluSetting  extends CommonSetting {
    {
        setting =  R.xml.setting_nlu;
        title = "语义理解设置";
    }
}
