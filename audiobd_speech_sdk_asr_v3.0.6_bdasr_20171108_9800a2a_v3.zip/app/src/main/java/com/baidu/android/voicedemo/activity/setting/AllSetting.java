package com.baidu.android.voicedemo.activity.setting;

import com.baidu.speech.recognizerdemo.R;

/**
 * Created by fujiayi on 2017/8/18.
 */

public class AllSetting extends CommonSetting {

    {
        setting = R.xml.setting_all;
        title = "全部识别设置";
    }
}
