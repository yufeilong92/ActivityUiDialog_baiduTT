百度语音识别SDK在demo程序中assets目录的文件解释说明:
WakeUp.bin                               唤醒功能的唤醒词配置文件, 需要在百度语音开发平台中定义和导出 http://speech.baidu.com/wake
baidu_speech_grammar.bsg                 自定义语义以及离线识别共用的语法文件, 需要在百度语音开发平台中定义和导出 http://speech.baidu.com/asr